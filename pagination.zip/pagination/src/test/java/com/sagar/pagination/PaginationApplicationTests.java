package com.sagar.pagination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginationApplicationTests {

	@Test
	void contextLoads() {
	}

}
